using UnityEngine;

public class Ghost : MonoBehaviour
{
    public int points = 200;
}
